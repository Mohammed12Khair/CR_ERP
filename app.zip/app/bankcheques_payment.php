<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bankcheques_payment extends Model
{
    //
}
