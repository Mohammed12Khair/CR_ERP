<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Activeaccounts extends Model
{
    //
}
