<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class transaction_sell_linesClone extends Model
{
    //
}
