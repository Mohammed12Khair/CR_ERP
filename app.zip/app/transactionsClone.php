<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class transactionsClone extends Model
{
    protected $fillable = ['*'];
    //
}
