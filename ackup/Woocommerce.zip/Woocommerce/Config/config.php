<?php

return [
    'name' => 'Woocommerce',
    'module_version' => "1.0"
];
