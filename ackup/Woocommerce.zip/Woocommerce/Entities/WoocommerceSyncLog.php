<?php

namespace Modules\Woocommerce\Entities;

use Illuminate\Database\Eloquent\Model;

class WoocommerceSyncLog extends Model
{
    protected $guarded = ['id'];
}
