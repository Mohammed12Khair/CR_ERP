<?php
 return [
"units" => "Unidades",
"manage_your_units" => "Administra tus unidades",
"all_your_units" => "Todas sus unidades",
"name" => "Nombre",
"short_name" => "Nombre corto",
"allow_decimal" => "Permitir decimal",
"added_success" => "Unidad añadida con éxito",
"updated_success" => "Unidad actualizada con éxito",
"deleted_success" => "Unidad eliminada con éxito",
"add_unit" => "Agregar unidad",
"edit_unit" => "Editar unidad",
];
