<?php
 return [
"categories" => "श्रेणियाँ",
"manage_your_categories" => "अपनी श्रेणियां प्रबंधित करें",
"all_your_categories" => "आपकी सभी श्रेणियां",
"category" => "वर्ग",
"category_name" => "श्रेणी नाम",
"code" => "श्रेणी कोड",
"add_as_sub_category" => "उप-श्रेणी के रूप में जोड़ें",
"select_parent_category" => "पैरेंट कैटेगरी चुनें",
"added_success" => "श्रेणी सफलतापूर्वक जोड़ा",
"updated_success" => "श्रेणी सफलतापूर्वक अपडेट की गई",
"deleted_success" => "श्रेणी को सफलतापूर्वक हटा दिया गया",
"add_category" => "कैटेगरी जोड़े",
"edit_category" => "श्रेणी संपादित करें",
];
