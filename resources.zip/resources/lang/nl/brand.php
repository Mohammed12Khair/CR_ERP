<?php
 return [
"brands" => "Merken",
"manage_your_brands" => "Beheer uw merken",
"all_your_brands" => "Al uw merken",
"note" => "Notitie",
"brand_name" => "Merknaam",
"short_description" => "Korte beschrijving",
"added_success" => "Merk met succes toegevoegd",
"updated_success" => "Merk succesvol bijgewerkt",
"deleted_success" => "Merk succesvol verwijderd",
"add_brand" => "Voeg merk toe",
"edit_brand" => "Merk bewerken",
];
