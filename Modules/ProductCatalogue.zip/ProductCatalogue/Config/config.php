<?php

return [
    'name' => 'ProductCatalogue',
    'module_version' => "0.8",
    'pid' => 8
];
