<?php
return [
	'productcatalogue_module' => 'Product Catalogue Module',
	'catalogue_qr' => 'QR code انشاء رمز',
	'generate_qr' => 'أنشاء QR',
	'select_business_location' => '  اختار الفرع ومجموعه الاسعار  ',
	'download_image' => 'تحميل الصوره',
	'qr_code_color' => 'Qr اختار لون',
	'catalogue_instruction_1' => 'أختار الفرع واللون',
	'catalogue_instruction_2' => 'اختار العوان الرئيسي والعنوان الفرعي',
	'catalogue_instruction_3' => 'أضغط لانشاء الكود',
	'product_catalogue' => 'Product Catalogue',
	'show_business_logo_on_qrcode' => 'أظهار شعار الشركة',
	'title' => 'العنوان الرئيسي',
	'subtitle' => 'العنوان الفرعي',
	'Selling' => 'مجموعه الاسعار ',
];