<div class="row row_options collapse">
	<div class="col-md-12 row_option cursor-pointer" data-ratio="12">
		<div class="col-md-12 bg-primary">1</div>
	</div>

	<div class="col-md-12 row_option cursor-pointer" data-ratio="6-6">
		<div class="col-md-6 bg-primary">1/2</div>
		<div class="col-md-6 bg-primary">1/2</div>
	</div>
	<div class="col-md-12 row_option cursor-pointer" data-ratio="6-3-3">
		<div class="col-md-6 bg-primary">1/2</div>
		<div class="col-md-3 bg-primary">1/3</div>
		<div class="col-md-3 bg-primary">1/3</div>
	</div>
	<div class="col-md-12 row_option cursor-pointer" data-ratio="3-3-6">
		<div class="col-md-3 bg-primary">1/3</div>
		<div class="col-md-3 bg-primary">1/3</div>
		<div class="col-md-6 bg-primary">1/2</div>
	</div>
	<div class="col-md-12 row_option cursor-pointer" data-ratio="4-4-4">
		<div class="col-md-4 bg-primary">1/3</div>
		<div class="col-md-4 bg-primary">1/3</div>
		<div class="col-md-4 bg-primary">1/3</div>
	</div>
	<div class="col-md-12 row_option cursor-pointer" data-ratio="3-3-3-3">
		<div class="col-md-3 bg-primary">1/4</div>
		<div class="col-md-3 bg-primary">1/4</div>
		<div class="col-md-3 bg-primary">1/4</div>
		<div class="col-md-3 bg-primary">1/4</div>
	</div>
	<div class="col-md-12 row_option cursor-pointer" data-ratio="3-9">
		<div class="col-md-3 bg-primary">1/4</div>
		<div class="col-md-9 bg-primary">3/4</div>
	</div>
	<div class="col-md-12 row_option cursor-pointer" data-ratio="9-3">
		<div class="col-md-9 bg-primary">3/4</div>
		<div class="col-md-3 bg-primary">1/4</div>
	</div>
</div>